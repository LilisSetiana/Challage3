package two.example.challageee

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_second.*
import kotlinx.android.synthetic.main.fragment_third.*


class ThirdFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_third, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val nama = arguments?.getString("nama")
        txt_nama.text = nama

        val dataUsia = arguments?.getInt("usia")
        val dataAlamat = arguments?.getString("alamat")
        val dataPekerjaan = arguments?.getString("pekerjaan")
        val dataKeterangan = arguments?.getString("keterangan")

        txt_usia.text = dataUsia.toString()
        txt_keterangan.text = dataKeterangan
        txt_alamat.text = dataAlamat
        txt_pekerjaan.text = dataPekerjaan



        gotoempat.setOnClickListener {
            val namaa = bundleOf("nama" to nama)
            Navigation.findNavController(view).navigate(R.id.navigasike_Fragmentempat, namaa)
        }
    }
}
